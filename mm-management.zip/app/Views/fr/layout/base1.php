<?= $this->include('fr/layout/header1') ?>
<?= $this->renderSection('content') ?>
<?= $this->include('fr/layout/footer1') ?>