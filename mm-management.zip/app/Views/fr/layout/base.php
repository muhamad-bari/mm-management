<?= $this->include('fr/layout/header') ?>
<?= $this->renderSection('content') ?>
<?= $this->include('fr/layout/footer') ?>